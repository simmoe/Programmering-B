<script>
</script>

<main class='page'>
    <div class="text">
        <h2>Welcome to the cocktail page</h2>
    </div>
    <img src="./assets/tail.avif" alt="">
</main>

<style>
	main{
        display:grid;
        grid-template-rows: 2fr 8fr;

    }

</style>