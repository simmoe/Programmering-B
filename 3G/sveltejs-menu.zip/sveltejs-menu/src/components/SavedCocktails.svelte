<script>

</script>

<main class='page'>
    <h1>Saved Cocktails</h1>
</main>

<style>
    
</style>