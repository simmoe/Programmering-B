## This repo is a modified version of svelte.js template to be used in programming class 
---

## svelte app

- A svelte app consist of a main.js file - this is where the show begins.
- It imports App.svelte which is our starting point
- From there we can create our own sub-components, usually in the folder 'components' 