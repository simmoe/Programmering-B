//opret server med express
const express = require('express')
const app = express()
const port = 4444
app.use('/', express.static('public'))
const server = app.listen(port, ()=>{
    console.log('server lytter på adressen: http://localhost:' + port)
})
//opret en socket 
const io = require('socket.io')
const serverSocket = io(server)

//Der kommer en ny klient - og serveren møder den her
serverSocket.on('connection', socket => {
    console.log('ny spiller, id: ' + socket.id)

    socket.on('disconnect', ()=>{
    })
})
