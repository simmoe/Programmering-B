## This repo is a modified version of svelte.js template to be used in programming class 
---

## svelte app

A svelte app consist of a main.js file - this is where the show begins. 