<script>
</script>

<main>
	<h1>Hello svelte!</h1>
</main>

<style>
	:global(*, body){
		box-sizing: border-box;
		margin:0;
		padding:0;
	}
	main {
		display:grid;
		place-items:center;
	}

	h1 {
		text-transform: uppercase;
		font-size: 2em;
		font-weight: 100;
	}
</style>